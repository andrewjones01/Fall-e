class NavigationArgs {
  static String token = "token";
}
