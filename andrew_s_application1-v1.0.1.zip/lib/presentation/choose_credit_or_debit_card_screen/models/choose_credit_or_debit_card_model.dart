import 'package:get/get.dart';
import 'slidervolume_item_model.dart';

class ChooseCreditOrDebitCardModel {
  RxList<SlidervolumeItemModel> slidervolumeItemList =
      RxList.filled(1, SlidervolumeItemModel());
}
