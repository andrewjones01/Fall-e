import 'package:andrew_s_application1/core/app_export.dart';
import 'package:andrew_s_application1/presentation/success_screen/models/success_model.dart';

class SuccessController extends GetxController {
  Rx<SuccessModel> successModelObj = SuccessModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
