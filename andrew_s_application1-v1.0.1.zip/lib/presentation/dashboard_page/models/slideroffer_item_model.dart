class SliderofferItemModel {}
