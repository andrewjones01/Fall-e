class FlashsaleItemModel {}
