class MegasaleItemModel {}
