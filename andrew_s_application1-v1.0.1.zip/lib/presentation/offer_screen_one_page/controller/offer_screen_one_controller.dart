import 'package:andrew_s_application1/core/app_export.dart';
import 'package:andrew_s_application1/presentation/offer_screen_one_page/models/offer_screen_one_model.dart';

class OfferScreenOneController extends GetxController {
  OfferScreenOneController(this.offerScreenOneModelObj);

  Rx<OfferScreenOneModel> offerScreenOneModelObj;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
