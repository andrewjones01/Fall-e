class OfferScreenOneModel {}
