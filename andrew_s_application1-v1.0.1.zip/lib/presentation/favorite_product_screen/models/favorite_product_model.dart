import 'package:get/get.dart';
import 'gridnikeairmaxreact_item_model.dart';

class FavoriteProductModel {
  RxList<GridnikeairmaxreactItemModel> gridnikeairmaxreactItemList =
      RxList.filled(4, GridnikeairmaxreactItemModel());
}
