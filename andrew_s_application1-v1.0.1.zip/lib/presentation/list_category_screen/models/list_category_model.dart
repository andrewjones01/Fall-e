class ListCategoryModel {}
