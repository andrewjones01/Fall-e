class ExploreItemModel {}
