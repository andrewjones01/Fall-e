class Explore1ItemModel {}
