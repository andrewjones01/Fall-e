class OfferScreenItemModel {}
