import 'package:andrew_s_application1/core/app_export.dart';
import 'package:andrew_s_application1/presentation/add_payment_screen/models/add_payment_model.dart';

class AddPaymentController extends GetxController {
  Rx<AddPaymentModel> addPaymentModelObj = AddPaymentModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
