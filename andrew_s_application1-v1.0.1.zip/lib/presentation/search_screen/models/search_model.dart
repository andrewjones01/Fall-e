class SearchModel {}
