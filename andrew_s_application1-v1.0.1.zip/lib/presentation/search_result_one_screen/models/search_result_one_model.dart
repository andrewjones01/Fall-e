class SearchResultOneModel {}
