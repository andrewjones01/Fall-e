import '../notification_offer_screen/widgets/listoffer_item_widget.dart';
import 'controller/notification_offer_controller.dart';
import 'models/listoffer_item_model.dart';
import 'package:andrew_s_application1/core/app_export.dart';
import 'package:andrew_s_application1/widgets/app_bar/appbar_image.dart';
import 'package:andrew_s_application1/widgets/app_bar/appbar_title.dart';
import 'package:andrew_s_application1/widgets/app_bar/custom_app_bar.dart';
import 'package:flutter/material.dart';

class NotificationOfferScreen extends GetWidget<NotificationOfferController> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        top: false,
        bottom: false,
        child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            appBar: CustomAppBar(
                height: getVerticalSize(56.00),
                leadingWidth: 40,
                leading: AppbarImage(
                    height: getSize(24.00),
                    width: getSize(24.00),
                    svgPath: ImageConstant.imgArrowleft,
                    margin: getMargin(left: 16, top: 16, bottom: 15),
                    onTap: onTapBack6),
                title: AppbarTitle(
                    text: "lbl_notification".tr, margin: getMargin(left: 12))),
            body: Padding(
                padding: getPadding(top: 12),
                child: Obx(() => ListView.separated(
                    physics: BouncingScrollPhysics(),
                    shrinkWrap: true,
                    separatorBuilder: (context, index) {
                      return SizedBox(height: getVerticalSize(1.00));
                    },
                    itemCount: controller.notificationOfferModelObj.value
                        .listofferItemList.length,
                    itemBuilder: (context, index) {
                      ListofferItemModel model = controller
                          .notificationOfferModelObj
                          .value
                          .listofferItemList[index];
                      return ListofferItemWidget(model);
                    })))));
  }

  onTapBack6() {
    Get.back();
  }
}
