import 'package:get/get.dart';
import 'listoffer_item_model.dart';

class NotificationOfferModel {
  RxList<ListofferItemModel> listofferItemList =
      RxList.filled(3, ListofferItemModel());
}
