class ListofferItemModel {}
