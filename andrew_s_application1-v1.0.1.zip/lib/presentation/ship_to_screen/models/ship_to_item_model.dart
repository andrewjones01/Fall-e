class ShipToItemModel {}
