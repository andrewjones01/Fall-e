import 'package:get/get.dart';
import 'ship_to_item_model.dart';

class ShipToModel {
  RxList<ShipToItemModel> shipToItemList = RxList.filled(3, ShipToItemModel());
}
