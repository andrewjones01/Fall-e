class NotificationItemModel {}
