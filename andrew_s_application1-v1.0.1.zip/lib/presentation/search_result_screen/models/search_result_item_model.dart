class SearchResultItemModel {}
