import 'package:get/get.dart';

class ShowonlyItemModel {
  Rx<String> freeReturnsTxt = Rx('"Free Returns"');

  RxBool isSelected = false.obs;
}
