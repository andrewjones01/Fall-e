import 'package:get/get.dart';

class BuyingformateItemModel {
  Rx<String> auctionTxt = Rx('"Auction"');

  RxBool isSelected = false.obs;
}
