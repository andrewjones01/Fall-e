import 'package:get/get.dart';

class ItemlocationItemModel {
  Rx<String> europeTxt = Rx('"Europe"');

  RxBool isSelected = false.obs;
}
