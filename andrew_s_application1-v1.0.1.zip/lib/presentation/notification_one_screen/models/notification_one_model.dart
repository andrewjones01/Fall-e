class NotificationOneModel {}
