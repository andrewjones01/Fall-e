import 'package:andrew_s_application1/core/app_export.dart';
import 'package:andrew_s_application1/presentation/notification_one_screen/models/notification_one_model.dart';

class NotificationOneController extends GetxController {
  Rx<NotificationOneModel> notificationOneModelObj = NotificationOneModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
