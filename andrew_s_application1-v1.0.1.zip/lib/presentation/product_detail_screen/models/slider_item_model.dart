class SliderItemModel {}
