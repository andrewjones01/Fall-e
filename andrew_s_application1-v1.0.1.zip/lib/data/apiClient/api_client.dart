import 'package:andrew_s_application1/core/app_export.dart';

class ApiClient extends GetConnect {}
