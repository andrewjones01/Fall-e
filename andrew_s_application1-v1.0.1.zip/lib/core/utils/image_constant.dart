class ImageConstant {
  static String imgClose8x8 = 'assets/images/img_close_8x8.svg';

  static String imgPlus28x24 = 'assets/images/img_plus_28x24.svg';

  static String imgMail70x70 = 'assets/images/img_mail_70x70.svg';

  static String imgArrowleft = 'assets/images/img_arrowleft.svg';

  static String imgArrowdown = 'assets/images/img_arrowdown.svg';

  static String imgProductpicture03 = 'assets/images/img_productpicture03.png';

  static String imgFilter = 'assets/images/img_filter.svg';

  static String imgColors = 'assets/images/img_colors.png';

  static String imgLock = 'assets/images/img_lock.svg';

  static String imgProfilepicture = 'assets/images/img_profilepicture.png';

  static String imgSort = 'assets/images/img_sort.svg';

  static String imgOffer24x24 = 'assets/images/img_offer_24x24.svg';

  static String imgDownload = 'assets/images/img_download.svg';

  static String imgClock = 'assets/images/img_clock.svg';

  static String imgImageproduct = 'assets/images/img_imageproduct.png';

  static String imgFacebook = 'assets/images/img_facebook.svg';

  static String imgAirplane = 'assets/images/img_airplane.svg';

  static String imgArrowleftLightBlueA200 =
      'assets/images/img_arrowleft_light_blue_a200.svg';

  static String imgProfilepicture1 = 'assets/images/img_profilepicture_1.png';

  static String imgArrowright = 'assets/images/img_arrowright.svg';

  static String imgSearchLightBlueA200 =
      'assets/images/img_search_light_blue_a200.svg';

  static String imgClose72x72 = 'assets/images/img_close_72x72.svg';

  static String imgUser24x24 = 'assets/images/img_user_24x24.svg';

  static String imgProductimage133x133 =
      'assets/images/img_productimage_133x133.png';

  static String imgUser = 'assets/images/img_user.svg';

  static String imgPaypalicon = 'assets/images/img_paypalicon.svg';

  static String imgUpload24x24 = 'assets/images/img_upload_24x24.svg';

  static String imgTrash24x24 = 'assets/images/img_trash_24x24.svg';

  static String imgForward = 'assets/images/img_forward.svg';

  static String imgCloseWhiteA700 = 'assets/images/img_close_white_a700.svg';

  static String imgProductimage1 = 'assets/images/img_productimage_1.png';

  static String imgWomanpantsicon = 'assets/images/img_womanpantsicon.svg';

  static String imgLightbulb = 'assets/images/img_lightbulb.svg';

  static String imgArrowleft24x24 = 'assets/images/img_arrowleft_24x24.svg';

  static String imgLogo = 'assets/images/img_logo.png';

  static String imgProductimage2 = 'assets/images/img_productimage_2.png';

  static String imgFolder = 'assets/images/img_folder.svg';

  static String imgCartLightBlueA200 =
      'assets/images/img_cart_light_blue_a200.svg';

  static String imgVector41 = 'assets/images/img_vector41.svg';

  static String imgUpload = 'assets/images/img_upload.svg';

  static String imgLock24x24 = 'assets/images/img_lock_24x24.svg';

  static String imgNotification = 'assets/images/img_notification.svg';

  static String imgRecomendedproduct =
      'assets/images/img_recomendedproduct.png';

  static String imgMobile = 'assets/images/img_mobile.svg';

  static String imgClose23x24 = 'assets/images/img_close_23x24.svg';

  static String imgProductimage3 = 'assets/images/img_productimage_3.png';

  static String imgPlus = 'assets/images/img_plus.svg';

  static String imgVolume = 'assets/images/img_volume.svg';

  static String imgSearch = 'assets/images/img_search.svg';

  static String imgMail = 'assets/images/img_mail.svg';

  static String imgTicket70x70 = 'assets/images/img_ticket_70x70.svg';

  static String imgMail24x24 = 'assets/images/img_mail_24x24.svg';

  static String imgFile = 'assets/images/img_file.svg';

  static String imgSearchLightBlueA2001 =
      'assets/images/img_search_light_blue_a200_1.svg';

  static String imgHighheelsicon = 'assets/images/img_highheelsicon.svg';

  static String imgProfilepicture48x48 =
      'assets/images/img_profilepicture_48x48.png';

  static String imgTrash70x70 = 'assets/images/img_trash_70x70.svg';

  static String imgProductpicture02 = 'assets/images/img_productpicture02.png';

  static String imgLocation = 'assets/images/img_location.svg';

  static String imgProductimage4 = 'assets/images/img_productimage_4.png';

  static String imgProductimage109x109 =
      'assets/images/img_productimage_109x109.png';

  static String imgBagicon = 'assets/images/img_bagicon.svg';

  static String imgCheckmark = 'assets/images/img_checkmark.svg';

  static String imgGoogle = 'assets/images/img_google.svg';

  static String imgArrowleftLightBlueA20070x70 =
      'assets/images/img_arrowleft_light_blue_a200_70x70.svg';

  static String imgCart = 'assets/images/img_cart.svg';

  static String imgCheckmark24x24 = 'assets/images/img_checkmark_24x24.svg';

  static String imgTicket = 'assets/images/img_ticket.svg';

  static String imgProductimage = 'assets/images/img_productimage.png';

  static String imgOffer = 'assets/images/img_offer.svg';

  static String imgNotification24x24 =
      'assets/images/img_notification_24x24.svg';

  static String imgTrash = 'assets/images/img_trash.svg';

  static String imgCalendar = 'assets/images/img_calendar.svg';

  static String imgComputer = 'assets/images/img_computer.svg';

  static String imgLoveicon = 'assets/images/img_loveicon.svg';

  static String imgProductpicture01 = 'assets/images/img_productpicture01.png';

  static String imgClose20x20 = 'assets/images/img_close_20x20.svg';

  static String imgHome = 'assets/images/img_home.svg';

  static String imgPromotionimage = 'assets/images/img_promotionimage.png';

  static String imgOfferBlueGray300 =
      'assets/images/img_offer_blue_gray_300.svg';

  static String imgAirplane24x24 = 'assets/images/img_airplane_24x24.svg';

  static String imgTrash1 = 'assets/images/img_trash_1.svg';

  static String imgOverflowmenu = 'assets/images/img_overflowmenu.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
